package com;

public class Student {

}
