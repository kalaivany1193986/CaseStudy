package kalai;
import java.util.*;
public class List {
	  
	 
	 @SuppressWarnings("rawtypes")
	public static void main(String args[]){  
	  ArrayList<String> list=new ArrayList<String>(); 
	  list.add("Ram");
	  list.add("Vino");  
	  list.add("Ram");  
	  list.add("Aja");  
	  System.out.println("ArrayList:");
	  Iterator itr=list.iterator();  
	  while(itr.hasNext()){  
	   System.out.println(itr.next());  
	  }  
	  
	 LinkedList<String> list1=new LinkedList<String>(); 
	  list1.add("Raji");
	  list1.add("Vinotha");  
	  list1.add("Ramya");  
	  list1.add("Ajaxa");  
	  System.out.println("LinkedList:");
	  Iterator itr1=list.iterator();  
	  while(itr1.hasNext()){  
	   System.out.println(itr1.next());  
	  }  
	 }  
	}  


