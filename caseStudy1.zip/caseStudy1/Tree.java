package kalai;
import java.util.Map;
import java.util.TreeMap;

 class Student {
	int id;
	String name;
	int marks;
	public Student(int id, String name, int marks) {
		super();
		this.id = id;
		this.name = name;
		this.marks = marks;
	}
	
	 
		}

	 
	

public class Tree {


public static void main(String[] args) {
	 
	    Student s1=new Student(1, "ram", 100);
	    Student s2=new Student(2, "ravi", 70);
	   
		Student s3=new Student(3, "raj", 90);
	    
		TreeMap<Integer,Student> m=new TreeMap<Integer,Student>();
		m.put(1,s3);
		m.put(2,s1);
		m.put(3,s2);
		
		
		for(Map.Entry<Integer, Student> i:m.entrySet())
		{
			 int key=i.getKey();  
		        Student b=i.getValue();  
		        System.out.println(key+" Details:");  
		        System.out.println("Id:"+b.id+" "+ "Name:"+b.name+" "+" Marks:"+b.marks);   
		}
	
	
	}

}
